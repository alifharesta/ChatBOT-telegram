/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.alifbot;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author m1nrc
 */
public class KoneksiMySQL {
    String url, usr, pwd, dbn;
    public KoneksiMySQL (String dbn) {
        this.url = "jdbc:mysql://localhost:3306/telebot"+dbn;
        this.usr = "root";
        this.pwd = "";
    }
    
    public KoneksiMySQL (String host, String user, String pass, String dbn) {
        this.url = "jdbc:mysql://" + host + "/" + dbn;
        this.usr = user;
        this.pwd = pass;
    }
    
    
    
    /*
    public static void main (String args[]) {
    KoneksiMysql kon = new KoneksiMysql ("barang");
    Connection c = kon.getConnection();
    }
    */
}
