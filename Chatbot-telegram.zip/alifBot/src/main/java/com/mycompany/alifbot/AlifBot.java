/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.alifbot;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.meta.exceptions.TelegramApiRequestException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

/**
 *
 * @author m1nrc
 */
public class AlifBot extends TelegramLongPollingBot {
    private static final String url = "jdbc:mysql://localhost:3306/telebot";
    private static final String usr = "root";
    private static final String pw = "";
    
    Connection Con;
    ResultSet RsUser;
    Statement stm;
    private Object[][] dataTable = null;
    
     public static void main(String[] args) throws TelegramApiException {
        AlifBot AlifBot = new AlifBot();
        try {
            TelegramBotsApi botsApi = new TelegramBotsApi(DefaultBotSession.class);
            botsApi.registerBot(AlifBot);
        } catch (TelegramApiRequestException e) {
            e.printStackTrace();
        }
    }
     
     @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            String messageText = update.getMessage().getText();
            long chatId = update.getMessage().getChatId();
            if(messageText.equals("/run")){
                startConversation(chatId);
            }
            else if (messageText.startsWith("/saveUser")) {
                String username = update.getMessage().getFrom().getUserName();
                // Menangani perintah /register
                String RegisterUser = registerUser(chatId, username);
                sendMessage(chatId, RegisterUser);

            }
            else if (messageText.startsWith("/info")) {
               String username = update.getMessage().getFrom().getUserName();
                // Menangani perintah /register
                String info = getUserInfo(chatId);
                sendMessage(chatId, info);

            }
            else{
                sendMessage(chatId, "Maaaf Keyword atau perintah  yang anda masukkan tidak ada");
            }
            saveMessage(chatId, messageText);
        
            
    }

    }
    
  private void startConversation(long chatId) {
        String welcomeMessage = "Welcome to Alipo bot"
                + "\nSilahkan pilih beberapa perintah di bawah"
                + "\n--------------------------------------------"
                + "\n /saveUser spasi (nama kamu) untuk registrasi pengguna baru"
                + "\n /info untuk melihat username anda"
                +"\n==================================="
                + "\n Chat anda akan terlihat dalam database kami";
        sendMessage(chatId, welcomeMessage);
    }
    
    private void saveMessage(long chatId, String message) {
        try (Connection connection = DriverManager.getConnection(url, usr, pw)) {
            String query = "INSERT INTO pesan (chat,id) VALUES (?,?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, chatId);
            statement.setString(2, message);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     private void sendResponse(long chatId, String response) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(response);
        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private String processMessage(String messageText) {
        String response = "";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, usr, pw);
            String query = "SELECT Jawab FROM pertanyaan WHERE pertanyaan = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, messageText);

            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                response = resultSet.getString("Jawab");
            } else {
                response = "Maaf, pertanyaan Anda tidak ditemukan.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response = "Terjadi kesalahan dalam memproses pertanyaan.";
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return response;
}
    
    private String registerUser(long chatId, String username) {
        try (Connection connection = DriverManager.getConnection(url, usr, pw)) {
            String query = "SELECT * FROM user WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, chatId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.print("User Sudah mendaftar");
                return "User Sudah mendaftar";
            } else {
                String query1 = "INSERT INTO user (nama, id) VALUES (?, ?)";
                PreparedStatement statement1 = connection.prepareStatement(query1);
                statement1.setString(2, username);
                statement1.setLong(1, chatId);
                statement1.executeUpdate();
                System.out.print("Registrasi Berhasil !!!");
                return "Registrasi Berhasil !!!";
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getUserInfo(long chatId) {
        try (Connection connection = DriverManager.getConnection(url, usr, pw)) {
            String query = "SELECT * FROM user WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setLong(1, chatId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String username = resultSet.getString("nama");
                return "User Info:\nUsername: " + username;
            } else {
                return "User not found!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void sendMessage(long chatId, String message) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText(message);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
    
    private void sapa(long chatId, String message) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText(message);

        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
    
    private boolean isAuthorizedUser(long chatId) {

    ResultSet resultSet = null;
        
    try(Connection connection = DriverManager.getConnection(url, usr, pw)) {
        String query = "SELECT * FROM user WHERE nama = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setLong(1, chatId);
        resultSet = statement.executeQuery();

        return resultSet.next();
    } catch (SQLException e) {
        e.printStackTrace();
    } 
    return false;
    }
    
    public void sendBroadcast(String message) {
        try (Connection conn = DriverManager.getConnection(url, usr, pw)) {
            
            String query = "SELECT id FROM user";
            
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String chatId = resultSet.getString("id");

                SendMessage sendMessage = new SendMessage();
                sendMessage.setChatId(chatId);
                sendMessage.setText(message);

                try {
                    execute(sendMessage);
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            JOptionPane.showMessageDialog(null, "Broadcast Sukses");
        }
    }
  
  @Override
  public String getBotUsername() {
      return "TakonAlip_bot";
  }
   @Override
  public String getBotToken() {
      return "6148752153:AAHAfGn4-EDjElLuZamKYfIZGWA0RuSb1zA";
  }

}
